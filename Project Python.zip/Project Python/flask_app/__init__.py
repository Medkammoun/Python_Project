from flask import Flask

app = Flask(__name__)

app.secret_key = "qsgdbwsgguilsgdli<diuqlsgmuowshgmodoshgmuwsgmwsggimudgwsimidgwsigisigdiwisgd"
DATABASE = "home_chef_python"